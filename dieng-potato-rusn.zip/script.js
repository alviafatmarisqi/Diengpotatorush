
console.log("Game started!");
// Tambahkan logika game di sini
